import { Component } from '@angular/core';

@Component({
  selector: 'lib-nova-ui',
  // imports: [],
  template: `
    <p>
      nova-ui works!
    </p>
  `,
  styles: ``
})
export class NovaUiComponent {

}
